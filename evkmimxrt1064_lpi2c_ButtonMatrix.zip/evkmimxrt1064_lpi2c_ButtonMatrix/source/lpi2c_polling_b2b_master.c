#include <stdio.h>
#include "board.h"
#include "fsl_debug_console.h"
#include "fsl_lpi2c.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "fsl_common.h"

#define I2C_MASTER_BASEADDR        LPI2C1
#define I2C_MASTER_CLK_FREQ        CLOCK_GetFreq(kCLOCK_Usb1PllPfd0Clk)
#define PCA9554B_ADDR              0x20  // Correct I2C 7-bit address
#define I2C_BAUDRATE               100000U

#define REG_INPUT_PORT             0x00
#define REG_CONFIG                 0x03

void delayMs(uint32_t ms)
{
    SDK_DelayAtLeastUs(ms * 1000, SystemCoreClock);
}

status_t PCA9554B_WriteRegister(uint8_t reg, uint8_t data)
{
    uint8_t tx[2] = {reg, data};
    return LPI2C_MasterStart(I2C_MASTER_BASEADDR, PCA9554B_ADDR, kLPI2C_Write) ||
           LPI2C_MasterSend(I2C_MASTER_BASEADDR, tx, 2) ||
           LPI2C_MasterStop(I2C_MASTER_BASEADDR);
}

status_t PCA9554B_ReadRegister(uint8_t reg, uint8_t *value)
{
    status_t status;

    status = LPI2C_MasterStart(I2C_MASTER_BASEADDR, PCA9554B_ADDR, kLPI2C_Write);
    if (status != kStatus_Success) return status;

    status = LPI2C_MasterSend(I2C_MASTER_BASEADDR, &reg, 1);
    if (status != kStatus_Success) return status;

    status = LPI2C_MasterRepeatedStart(I2C_MASTER_BASEADDR, PCA9554B_ADDR, kLPI2C_Read);
    if (status != kStatus_Success) return status;

    status = LPI2C_MasterReceive(I2C_MASTER_BASEADDR, value, 1);
    if (status != kStatus_Success) return status;

    return LPI2C_MasterStop(I2C_MASTER_BASEADDR);
}

void PCA9554B_Init(void)
{
    // Set all pins as input (1 = input)
    if (PCA9554B_WriteRegister(REG_CONFIG, 0xFF) != kStatus_Success)
    {
        PRINTF("Failed to configure PCA9554B\r\n");
    }
}

void ScanButtons(void)
{
    static uint8_t prevState = 0xFF;  // All released
    uint8_t currState;

    if (PCA9554B_ReadRegister(REG_INPUT_PORT, &currState) != kStatus_Success)
    {
      //  PRINTF("Read failed\r\n");
        return;
    }

    delayMs(5);  // Debounce
    uint8_t confirm;
    if (PCA9554B_ReadRegister(REG_INPUT_PORT, &confirm) != kStatus_Success || confirm != currState)
        return;

    for (int i = 0; i < 8; i++)
    {
        uint8_t mask = (1 << i);
        if ((prevState & mask) && !(currState & mask))
        {
            PRINTF("Button %d pressed\r\n", i + 1);
        }
    }

    prevState = currState;
}

int main(void)
{
    BOARD_ConfigMPU();
    BOARD_InitBootPins();
    BOARD_InitBootClocks();
    BOARD_InitDebugConsole();

    PRINTF("PCA9554B Button Matrix Initialized\r\n");

    lpi2c_master_config_t config;
    LPI2C_MasterGetDefaultConfig(&config);
    config.baudRate_Hz = I2C_BAUDRATE;
    LPI2C_MasterInit(I2C_MASTER_BASEADDR, &config, I2C_MASTER_CLK_FREQ);

    PCA9554B_Init();

    while (1)
    {
        ScanButtons();
        delayMs(200);  // Adjust for responsiveness
    }
}
